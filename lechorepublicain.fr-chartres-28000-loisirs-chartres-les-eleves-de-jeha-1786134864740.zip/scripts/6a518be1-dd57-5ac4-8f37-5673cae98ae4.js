window._hbdbrk = window._hbdbrk || [];
window._hbdbrk.push([ '_id', '6a518be1-dd57-5ac4-8f37-5673cae98ae4' ]);

var hbdbrkElements = [];
var st = document.createElement('script');
// The modern bundle targets browsers that natively support IntersectionObserver,
// ResizeObserver and Element.after(). Without this feature-gate, iOS Safari
// 10.3–13.3 (module-capable but missing those Web APIs) would receive the
// modern bundle together with the near-empty modern polyfill and crash.
var supportModule = 'noModule' in st
  && 'IntersectionObserver' in window
  && 'IntersectionObserverEntry' in window
  && 'ResizeObserver' in window
  && typeof document.head.after === 'function';
window._hbdbrk.push([ '_module', supportModule ]);

var hbdbrkConfig = supportModule ? {"main":"assets/js/hbdbrk_213686de40e315b19b70_m.js","style":"assets/css/hbdbrk_213686de40e315b19b70.css","dependencies":[],"polyfill":["assets/js/polyfill_b0e0ebfc9859683be87e_m.js"]} : {"main":"assets/js/hbdbrk_2b7921ef04b7373d3a0a.js","style":"assets/css/hbdbrk_2b7921ef04b7373d3a0a.css","dependencies":[],"polyfill":["assets/js/polyfill_a978280a1b42efeacc92.js"]};

try {
  if (
    !(window.ResizeObserver && 'IntersectionObserver' in window)
    || !('IntersectionObserverEntry' in window)
    || typeof document.head.after != 'function')
  {
    var pl = document.createElement('script');
    pl.type = 'text/javascript';
    pl.async = true;
    pl.src = 'https://www.flashb.id/' + hbdbrkConfig.polyfill;
    document.head.insertAdjacentElement('afterbegin', pl);
  }
} catch (e) {
}

//add main script
st.type = 'text/javascript';
st.async = true;
st.src = 'https://www.flashb.id/' + hbdbrkConfig.main;
hbdbrkElements.push(st);
// Preload Sparteo dependencies.js (cross-origin) so its TCP/TLS handshake
// and download start as early as possible, in parallel with hbdbrk.js.
// hbdbrk.js injects the actual <script> tag for dependencies.js later;
// this preload only warms the cache so window.sparteo.abTests is exposed
// before the first tracking events (site/session, site/page, cmp/*) fire.
var depsPreload = document.createElement('link');
depsPreload.rel = 'preload';
depsPreload.as = 'script';
depsPreload.href = 'https://assets.sparteo.com/dependencies.js';
hbdbrkElements.push(depsPreload);

var hbdbrkDependencies = hbdbrkConfig.dependencies ? hbdbrkConfig.dependencies : [];

for (var i = 0; i < hbdbrkDependencies.length; i++) {
  var st = document.createElement('link');
  st.rel = 'preload';
  st.as = 'script';
  st.href = 'https://www.flashb.id/' + hbdbrkDependencies[i];
  hbdbrkElements.push(st);
}

if (hbdbrkConfig.style) {
  var se = document.createElement('link');
  se.rel = 'stylesheet';
  se.href = 'https://www.flashb.id/' + hbdbrkConfig.style;
  hbdbrkElements.push(se);
}

for (var p in hbdbrkElements) {
  document.head.insertAdjacentElement('afterbegin', hbdbrkElements[p]);
}
